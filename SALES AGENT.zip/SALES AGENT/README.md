# Wakala Pro

Wakala Pro is a mobile-first, offline-capable sales agent management app. It stores data in the browser on the device; there is no server account or paid service.

## Run locally

1. Install Node.js or Python if it is not already installed.
2. Open PowerShell in this project folder.
3. Start a local web server using either command:

   ```powershell
   npx serve .
   ```

   Or:

   ```powershell
   python -m http.server 8000
   ```

4. Open the URL printed by `serve`, or visit `http://localhost:8000`.

Do not open `index.html` directly as a file. Browsers require a local server for ES modules, IndexedDB and the service worker. Tailwind and Chart.js are included in `vendor/`; the app does not load a CDN or need a build step.

## Test on your phone

For a quick layout test on the same Wi-Fi:

1. Find your computer's local IPv4 address with `ipconfig`.
2. Start the server so it listens on your network:

   ```powershell
   python -m http.server 8000 --bind 0.0.0.0
   ```

3. On your phone, open `http://COMPUTER-IP:8000` (replace `COMPUTER-IP` with the IPv4 address). Allow the connection through Windows Firewall if prompted.

Plain local HTTP is suitable for trying the screens and saving data, but browsers require a secure HTTPS origin (or `localhost`) for service workers, installation and some notification features. Use one of the free HTTPS deployments below to test the complete PWA on a phone.

## Install on a phone

Deploy to an HTTPS address first, then open that address on your phone:

- **Android / Chrome:** open the browser menu and tap **Install app** or **Add to Home screen**.
- **iPhone / Safari:** tap **Share**, then **Add to Home Screen**.

The app and its libraries are cached for offline use after the first successful load. Customer, sale, settings and expense data are stored only in that browser's local IndexedDB. They do not automatically sync between devices.

## Free deployment

### Netlify

1. Create a free account at Netlify.
2. Choose **Add new site** / **Deploy manually**.
3. Drag the complete project folder (including `vendor`, `js`, `css`, `icons`, `index.html`, `manifest.json` and `sw.js`) into the deploy area.
4. Open the generated HTTPS URL on your phone.

### GitHub Pages

1. Create a GitHub repository and upload the project files to its root.
2. In the repository, open **Settings → Pages**.
3. Select **Deploy from a branch**, choose the main branch and root folder, then save.
4. Wait for the Pages URL and open its HTTPS address.

The app uses relative paths, so it can also run from a GitHub Pages project subpath.

## Back up and restore

Open **Zaidi → Nakala kamili JSON** regularly and keep the downloaded file somewhere safe. The JSON file contains customers, sales, expenses and settings. Use **Rejesha nakala JSON** to restore it; restoring replaces the current data on that device. CSV downloads are available for customers, sales and expenses, and a CSV with customer columns such as `Jina,Simu,Eneo,Huduma,Chanzo,Hatua` can be imported.

Clearing browser data or uninstalling the browser may remove local records. A backup is the only way to move or recover your information.

## Suggested checks

- Add, edit and delete a customer; try a duplicate phone number and an invalid Tanzanian number.
- Search and filter customers, change their status, add a dated note, and open the call and WhatsApp links.
- Set a follow-up for today and one for yesterday; verify the dashboard sections and optional notification permission.
- Record a Halotel and a Tigo Fibre sale; check automatic commission and installation status.
- Add expenses, switch finance periods, and verify profit equals commission minus expenses.
- Set a monthly target and commission rates; check the dashboard target and charts.
- Export each CSV and a JSON backup, then restore the JSON backup.
- Import a small customer CSV and check duplicate/invalid rows are reported.
- Add and remove sample data, set a PIN, reload to test the lock, and test dark mode.
- Load the deployed app once, switch off the network, and reopen it to test offline caching.
