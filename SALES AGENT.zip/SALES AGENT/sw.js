const CACHE_NAME = "wakala-pro-v5";
const APP_FILES = [
  "./", "./index.html", "./manifest.json", "./css/style.css",
  "./js/db.js", "./js/customers.js", "./js/sales.js", "./js/finance.js",
  "./js/dashboard.js", "./js/settings.js", "./js/ui.js",
  "./vendor/tailwindcss.js", "./vendor/chart.umd.min.js",
  "./icons/icon-192.svg", "./icons/icon-512.svg", "./icons/icon-192.png", "./icons/icon-512.png"
];

self.addEventListener("install", event => {
  event.waitUntil(caches.open(CACHE_NAME).then(cache => cache.addAll(APP_FILES)));
  self.skipWaiting();
});

self.addEventListener("activate", event => {
  event.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(key => key !== CACHE_NAME).map(key => caches.delete(key)))));
  self.clients.claim();
});

self.addEventListener("fetch", event => {
  if (event.request.method !== "GET") return;
  event.respondWith(caches.match(event.request).then(cached => cached || fetch(event.request).then(response => {
    if (new URL(event.request.url).origin === self.location.origin && response.ok) {
      const copy = response.clone();
      caches.open(CACHE_NAME).then(cache => cache.put(event.request, copy));
    }
    return response;
  }).catch(() => caches.match("./index.html"))));
});
