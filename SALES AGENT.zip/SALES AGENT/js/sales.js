import { getAll, put, remove, createId } from "./db.js";
import { changeCustomerStatus } from "./customers.js";

// Huhesabu kamisheni kwa asilimia au kiasi maalumu cha huduma.
export function calculateCommission(amount, service, settings) {
  const rate = settings.commission?.[service] || { mode: "percent", value: 0 };
  return Math.round(rate.mode === "fixed" ? Number(rate.value) : Number(amount) * Number(rate.value) / 100);
}

// Huhifadhi mauzo na kusasisha hatua ya mteja kuwa amefunga.
export async function saveSale(sale, settings) {
  if (!sale.customerId) throw new Error("Chagua mteja wa mauzo.");
  if (!["halotel", "tigo"].includes(sale.service)) throw new Error("Chagua huduma sahihi.");
  if (!sale.bundle?.trim()) throw new Error("Weka kifurushi au maelezo ya huduma.");
  const amount = Number(sale.amount);
  if (!Number.isFinite(amount) || amount <= 0) throw new Error("Kiasi cha mauzo lazima kiwe zaidi ya sifuri.");
  const customer = (await getAll("customers")).find(item => item.id === sale.customerId);
  if (!customer) throw new Error("Mteja aliyechaguliwa hapatikani.");
  const saved = { ...sale, id: sale.id || createId(), amount, commission: calculateCommission(amount, sale.service, settings), date: sale.date || new Date().toISOString().slice(0, 10), installation: sale.service === "tigo" ? (sale.installation || "Inasubiri") : "", createdAt: sale.createdAt || new Date().toISOString() };
  await put("sales", saved);
  await changeCustomerStatus(customer.id, "Nimefunga");
  return saved;
}

// Husasisha hali ya ufungaji kwa mauzo ya Tigo Fibre.
export async function updateInstallation(id, installation) {
  if (!["Inasubiri", "Imewekwa", "Imekwama"].includes(installation)) throw new Error("Hali ya ufungaji si sahihi.");
  const sale = (await getAll("sales")).find(item => item.id === id);
  if (!sale) throw new Error("Mauzo haya hayapatikani.");
  sale.installation = installation;
  await put("sales", sale);
}

// Huondoa mauzo kwa kitambulisho chake.
export const deleteSale = id => remove("sales", id);
