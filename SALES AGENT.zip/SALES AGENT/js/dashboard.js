import { getAll } from "./db.js";

// Hutoa tarehe ya kifaa katika muundo wa YYYY-MM-DD.
function dateKey(date) {
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
}

// Hupanga kipindi cha kuanzia Jumatatu hadi Jumapili ya wiki ya sasa.
export function currentWeekRange(now = new Date()) {
  const monday = new Date(now);
  monday.setHours(0, 0, 0, 0);
  monday.setDate(monday.getDate() - ((monday.getDay() + 6) % 7));
  const sunday = new Date(monday);
  sunday.setDate(monday.getDate() + 6);
  return [dateKey(monday), dateKey(sunday)];
}

// Hukusanya vipimo vya nyumbani, ufuatiliaji na maeneo.
export async function getDashboardData(settings) {
  const [customers, sales, expenses] = await Promise.all([getAll("customers"), getAll("sales"), getAll("expenses")]);
  const now = new Date();
  const today = dateKey(now);
  const month = today.slice(0, 7);
  const [weekStart, weekEnd] = currentWeekRange(now);
  const monthSales = sales.filter(sale => sale.date.startsWith(month));
  const monthExpenses = expenses.filter(expense => expense.date.startsWith(month));
  const monthCommission = monthSales.reduce((sum, sale) => sum + Number(sale.commission || 0), 0);
  const monthSpending = monthExpenses.reduce((sum, item) => sum + Number(item.amount || 0), 0);
  const leads = customers.filter(customer => customer.status !== "Nimefunga");
  const areas = new Map();
  for (const customer of customers) {
    const key = customer.area || "Eneo halijatajwa";
    const item = areas.get(key) || { name: key, leads: 0, sales: 0, amount: 0 };
    item.leads++;
    const customerSales = sales.filter(sale => sale.customerId === customer.id);
    item.sales += customerSales.length;
    item.amount += customerSales.reduce((sum, sale) => sum + Number(sale.amount || 0), 0);
    areas.set(key, item);
  }
  return {
    customers, sales, expenses, today, month,
    newCustomers: customers.filter(customer => customer.createdAt?.startsWith(month)).length,
    monthSales: monthSales.length, monthCommission, monthSpending, monthProfit: monthCommission - monthSpending,
    conversion: customers.length ? Math.round((customers.filter(customer => customer.status === "Nimefunga").length / customers.length) * 100) : 0,
    target: Number(settings.monthlyTarget || 0),
    targetProgress: Number(settings.monthlyTarget) > 0 ? Math.min(100, Math.round(monthCommission / Number(settings.monthlyTarget) * 100)) : 0,
    todayFollowUps: customers.filter(customer => customer.followUpDate === today),
    overdueFollowUps: customers.filter(customer => customer.followUpDate && customer.followUpDate < today && !["Nimefunga", "Amekataa"].includes(customer.status)),
    weekSales: sales.filter(sale => sale.date >= weekStart && sale.date <= weekEnd),
    areas: [...areas.values()].sort((a, b) => b.amount - a.amount),
    opportunities: [...areas.values()].filter(area => area.leads >= 2 && area.sales / area.leads < .35).sort((a, b) => (b.leads - b.sales) - (a.leads - a.sales))
  };
}
