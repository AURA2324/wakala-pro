import { getAll, getSettings, saveSettings, put, importDatabase } from "./db.js";
import { CUSTOMER_STATUSES, SERVICES, normalizePhone, saveCustomer, changeCustomerStatus, addCustomerNote, deleteCustomer } from "./customers.js";
import { saveSale, updateInstallation, deleteSale } from "./sales.js";
import { EXPENSE_TYPES, saveExpense, deleteExpense, getFinanceSummary } from "./finance.js";
import { getDashboardData, currentWeekRange } from "./dashboard.js";
import { exportBackup, downloadCSV, parseCSV, clearAllData, hashPin } from "./settings.js";

const main = document.querySelector("#main-content");
const modalRoot = document.querySelector("#modal-root");
const toast = document.querySelector("#toast");
const state = { page: "home", settings: null, filter: { search: "", status: "", service: "", area: "" }, financeRange: "month", financeStart: "", financeEnd: "", chartInstances: [], authenticated: false };
let toastTimer;

// Huzuia maandishi ya mtumiaji kuingizwa kama HTML.
function escapeHTML(value = "") {
  return String(value).replace(/[&<>"']/g, char => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[char]);
}

// Huonyesha ujumbe mfupi wa mafanikio au kosa.
function notify(message, error = false) {
  toast.textContent = message;
  toast.classList.toggle("error", error);
  toast.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove("show"), 2800);
}

// Hutoa tarehe ya leo kwa eneo la kifaa bila mabadiliko ya UTC.
function localDate(date = new Date()) {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}

// Huonyesha kiasi cha fedha katika muundo wa Tanzania.
function money(amount) {
  return `TSh ${Math.round(Number(amount || 0)).toLocaleString("en-US")}`;
}

// Hubadilisha nambari ya huduma kuwa jina linalosomeka.
function serviceName(service) {
  return service === "tigo" ? "Tigo Fibre" : service === "halotel" ? "Halotel" : "Zote";
}

// Huonyesha jina la hatua kwa darasa la rangi linalolingana.
function statusBadge(status) {
  const slug = status.toLowerCase().replaceAll(" ", "");
  return `<span class="badge status-${slug}">${escapeHTML(status)}</span>`;
}

// Hutengeneza hali tupu ya orodha kwa ujumbe wa Kiswahili.
function emptyState(title, message, action = "") {
  return `<div class="empty-state"><div class="empty-icon">☀</div><strong>${title}</strong><span>${message}</span>${action ? `<div style="margin-top:14px">${action}</div>` : ""}</div>`;
}

// Hufungua dirisha la modal na kuweka kichwa pamoja na maudhui yake.
function showModal(title, content) {
  modalRoot.innerHTML = `<div class="modal-backdrop" data-close-modal><section class="modal" role="dialog" aria-modal="true" aria-label="${escapeHTML(title)}"><div class="modal-header"><h2>${escapeHTML(title)}</h2><button class="modal-close" data-action="close-modal" aria-label="Funga">×</button></div>${content}</section></div>`;
  modalRoot.querySelector("[data-close-modal]")?.addEventListener("click", event => { if (event.target.matches("[data-close-modal]")) closeModal(); });
  modalRoot.querySelector("input,select,textarea")?.focus();
}

// Hufunga modal iliyo wazi.
function closeModal() { modalRoot.innerHTML = ""; }

// Huunda chaguo za huduma na hatua kwa fomu.
function options(items, selected = "") {
  return items.map(item => `<option value="${escapeHTML(item.value)}" ${item.value === selected ? "selected" : ""}>${escapeHTML(item.label)}</option>`).join("");
}

// Hutoa chaguo la hatua ya mteja.
function statusOptions(selected) {
  return options(CUSTOMER_STATUSES.map(value => ({ value, label: value })), selected);
}

// Huwasha ukurasa uliochaguliwa kwenye menyu ya chini.
function setPage(page) {
  state.page = page;
  document.querySelectorAll(".nav-item").forEach(button => button.classList.toggle("active", button.dataset.page === page));
  render();
}

// Hupanga uwasilishaji wa kila ukurasa wa programu.
async function render() {
  if (!state.settings) state.settings = await getSettings();
  try {
    if (state.page === "home") await renderDashboard();
    else if (state.page === "customers") await renderCustomers();
    else if (state.page === "sales") await renderSales();
    else if (state.page === "finance") await renderFinance();
    else await renderMore();
  } catch (error) {
    main.innerHTML = emptyState("Kuna tatizo", escapeHTML(error.message || "Imeshindikana kupakia taarifa."));
  }
}

// Hutoa kadi ya mfuatiliaji wa leo au uliochelewa.
function followUpCard(customer, overdue = false) {
  return `<article class="card follow-card"><div class="follow-info"><div class="follow-name">${escapeHTML(customer.name)}</div><div class="follow-meta">${escapeHTML(customer.phone)} · ${escapeHTML(customer.area || "Eneo halijatajwa")}</div><div class="follow-meta">${escapeHTML(serviceName(customer.service))}</div><div class="card-actions"><a class="button button-secondary" href="tel:+${escapeHTML(customer.phone)}">Piga simu</a><button class="button button-primary" data-action="customer-view" data-id="${customer.id}">Fungua</button></div></div><div class="follow-date">${overdue ? "Imechelewa" : "Leo"}</div></article>`;
}

// Huchora chati kwa Chart.js ikiwa imepakuliwa na kupatikana.
function makeChart(canvas, type, labels, datasets, optionsExtra = {}) {
  if (!canvas || !window.Chart) return;
  const chart = new Chart(canvas, {
    type, data: { labels, datasets },
    options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { display: type !== "line", position: "bottom", labels: { boxWidth: 10, usePointStyle: true } } }, scales: type === "doughnut" ? {} : { y: { beginAtZero: true, ticks: { precision: 0 } } }, ...optionsExtra }
  });
  state.chartInstances.push(chart);
}

// Huchora ukurasa wa nyumbani na takwimu muhimu za biashara.
async function renderDashboard() {
  state.chartInstances.forEach(chart => chart.destroy());
  state.chartInstances = [];
  const data = await getDashboardData(state.settings);
  const todayFollow = data.todayFollowUps;
  const overdueFollow = data.overdueFollowUps;
  const days = ["Jumatatu", "Jumanne", "Jumatano", "Alhamisi", "Ijumaa", "Jumamosi", "Jumapili"];
  const [weekStart] = currentWeekRange(new Date());
  const weekLabels = days.map((_, index) => {
    const date = new Date(`${weekStart}T12:00:00`);
    date.setDate(date.getDate() + index);
    return date.toLocaleDateString("sw-TZ", { weekday: "short" });
  });
  const salesPerDay = weekLabels.map((_, index) => {
    const date = new Date(`${weekStart}T12:00:00`);
    date.setDate(date.getDate() + index);
    const key = localDate(date);
    return data.weekSales.filter(sale => sale.date === key).reduce((sum, sale) => sum + Number(sale.amount || 0), 0);
  });
  const halotelCount = data.sales.filter(sale => sale.service === "halotel").length;
  const tigoCount = data.sales.filter(sale => sale.service === "tigo").length;
  const topAreas = data.areas.slice(0, 5);
  main.innerHTML = `
    <h1 class="page-title">Habari, wakala! 👋</h1><p class="page-subtitle">${new Date().toLocaleDateString("sw-TZ", { weekday: "long", day: "numeric", month: "long" })} · Huu ndio muhtasari wa biashara yako.</p>
    <div class="grid stats-grid">
      <article class="stat-card"><span class="stat-icon">♙</span><div class="stat-label">Wateja wapya mwezi huu</div><div class="stat-value">${data.newCustomers}</div><div class="stat-foot">Wateja wote: ${data.customers.length}</div></article>
      <article class="stat-card"><span class="stat-icon">▣</span><div class="stat-label">Mauzo mwezi huu</div><div class="stat-value">${data.monthSales}</div><div class="stat-foot">Kiwango cha ubadilishaji: ${data.conversion}%</div></article>
      <article class="stat-card"><span class="stat-icon">↗</span><div class="stat-label">Kamisheni mwezi huu</div><div class="stat-value">${money(data.monthCommission)}</div><div class="stat-foot">Faida: ${money(data.monthProfit)}</div></article>
      <article class="stat-card"><span class="stat-icon">↘</span><div class="stat-label">Matumizi mwezi huu</div><div class="stat-value">${money(data.monthSpending)}</div><div class="stat-foot">Yameondolewa kwenye faida</div></article>
      <article class="stat-card target-card"><div class="stat-label">Lengo la kamisheni mwezi huu</div><div class="stat-value">${money(data.monthCommission)} <span style="font-size:13px;font-weight:500">/ ${money(data.target)}</span></div><div class="progress-track"><div class="progress-fill" style="width:${data.targetProgress}%"></div></div><div class="stat-foot">${data.targetProgress}% ya lengo imefikiwa</div></article>
    </div>
    <div class="section-heading"><h2>Leo nafuatilia</h2><a href="#" data-page-link="customers">Wateja wote</a></div>
    <div class="grid">${todayFollow.length ? todayFollow.map(customer => followUpCard(customer)).join("") : emptyState("Hakuna ufuatiliaji wa leo", "Umefanya vizuri! Weka tarehe ya ufuatiliaji kwa wateja wako.")}</div>
    <div class="section-heading"><h2>Zimechelewa</h2></div>
    <div class="grid">${overdueFollow.length ? overdueFollow.map(customer => followUpCard(customer, true)).join("") : emptyState("Hakuna ufuatiliaji uliochelewa", "Uko vizuri. Kumbuka kupanga ufuatiliaji ujao.")}</div>
    <div class="section-heading"><h2>Muonekano wa biashara</h2></div>
    <div class="chart-grid"><article class="card chart-card"><h3>Kiasi cha mauzo kwa wiki</h3><div class="chart-wrap"><canvas id="weekly-chart" aria-label="Chati ya kiasi cha mauzo kwa wiki"></canvas></div></article>
    <article class="card chart-card"><h3>Huduma zilizouzwa</h3><div class="chart-wrap"><canvas id="service-chart" aria-label="Chati ya huduma zilizouzwa"></canvas></div></article>
    <article class="card chart-card"><h3>Maeneo bora kwa mauzo</h3><div class="chart-wrap"><canvas id="areas-chart" aria-label="Chati ya maeneo bora kwa mauzo"></canvas></div></article></div>
    <button class="fab" data-action="customer-add" aria-label="Ongeza mteja">＋</button>`;
  makeChart(document.querySelector("#weekly-chart"), "line", weekLabels, [{ label: "Mauzo", data: salesPerDay, borderColor: "#087f5b", backgroundColor: "#087f5b22", fill: true, tension: .35 }]);
  makeChart(document.querySelector("#service-chart"), "doughnut", ["Halotel", "Tigo Fibre"], [{ data: [halotelCount, tigoCount], backgroundColor: ["#087f5b", "#2875c7"], borderWidth: 0 }]);
  makeChart(document.querySelector("#areas-chart"), "bar", topAreas.map(area => area.name), [{ label: "Mauzo (TSh)", data: topAreas.map(area => area.amount), backgroundColor: "#2875c7", borderRadius: 6 }]);
}

// Huonyesha kadi moja ya mteja na vitendo vyake vya haraka.
function customerCard(customer) {
  const normalized = normalizePhone(customer.phone);
  const template = customer.service === "tigo" ? state.settings.templates.tigo : state.settings.templates.halotel;
  const message = template.replaceAll("{jina}", customer.name);
  const waLink = `https://wa.me/${normalized}?text=${encodeURIComponent(message)}`;
  const statusKey = customer.status.toLowerCase().replaceAll(" ", "");
  return `<article class="card customer-card"><div class="customer-head"><div><div class="customer-name">${escapeHTML(customer.name)}</div><div class="customer-phone">${escapeHTML(customer.phone)}</div></div>${statusBadge(customer.status)}</div>
    <div class="customer-details"><span>⌖ ${escapeHTML(customer.area || "Eneo halijatajwa")}</span><span>· ${escapeHTML(serviceName(customer.service))}</span><span>· ${escapeHTML(customer.source || "Nyingine")}</span><span>· Imeongezwa: ${new Date(customer.createdAt || Date.now()).toLocaleDateString("sw-TZ")}</span></div>
    <div class="field"><label class="field-hint" for="status-${customer.id}">Badili hatua kwa haraka</label><select class="control status-select status-${statusKey}" id="status-${customer.id}" data-action="status-change" data-id="${customer.id}">${statusOptions(customer.status)}</select></div>
    ${customer.followUpDate ? `<div class="follow-meta" style="margin-top:9px">Ufuatiliaji: ${escapeHTML(customer.followUpDate)}</div>` : ""}
    <div class="card-actions"><a class="button button-secondary" href="tel:+${escapeHTML(normalized)}">Piga simu</a><a class="button button-secondary" href="${waLink}" target="_blank" rel="noopener">WhatsApp</a><button class="button button-secondary" data-action="customer-view" data-id="${customer.id}">Dokezo</button><button class="button button-secondary" data-action="customer-edit" data-id="${customer.id}">Hariri</button></div></article>`;
}

// Huchuja wateja kwa utafutaji, hatua, huduma na eneo.
async function renderCustomers() {
  const customers = await getAll("customers");
  const areas = [...new Set(customers.map(item => item.area).filter(Boolean))].sort();
  const filtered = customers.filter(customer =>
    (!state.filter.search || `${customer.name} ${customer.phone} ${customer.area}`.toLowerCase().includes(state.filter.search.toLowerCase())) &&
    (!state.filter.status || customer.status === state.filter.status) &&
    (!state.filter.service || customer.service === state.filter.service || customer.service === "zote") &&
    (!state.filter.area || customer.area === state.filter.area)
  ).sort((a, b) => (b.createdAt || "").localeCompare(a.createdAt || ""));
  main.innerHTML = `<h1 class="page-title">Wateja</h1><p class="page-subtitle">${customers.length} jumla · Tunza mahusiano na usikose fursa.</p>
    <input class="search-input" data-filter="search" placeholder="Tafuta jina, simu au eneo..." value="${escapeHTML(state.filter.search)}" aria-label="Tafuta wateja">
    <div class="filter-row">
      <select data-filter="status" aria-label="Chuja kwa hatua"><option value="">Hatua zote</option>${CUSTOMER_STATUSES.map(value => `<option ${state.filter.status === value ? "selected" : ""}>${value}</option>`).join("")}</select>
      <select data-filter="service" aria-label="Chuja kwa huduma"><option value="">Huduma zote</option><option value="halotel" ${state.filter.service === "halotel" ? "selected" : ""}>Halotel</option><option value="tigo" ${state.filter.service === "tigo" ? "selected" : ""}>Tigo Fibre</option><option value="zote" ${state.filter.service === "zote" ? "selected" : ""}>Zote</option></select>
      <select data-filter="area" aria-label="Chuja kwa eneo"><option value="">Maeneo yote</option>${areas.map(area => `<option ${state.filter.area === area ? "selected" : ""}>${escapeHTML(area)}</option>`).join("")}</select>
    </div>
    <div class="section-heading"><h2>Orodha ya wateja</h2><button class="button button-primary button-small" data-action="customer-add">＋ Ongeza</button></div>
    <div class="customer-list">${filtered.length ? filtered.map(customerCard).join("") : emptyState("Hakuna mteja hapa", customers.length ? "Jaribu kubadili utafutaji au vichujio." : "Ongeza mteja wako wa kwanza ili uanze kufuatilia mauzo.", '<button class="button button-primary" data-action="customer-add">Ongeza mteja</button>')}</div>
    <button class="fab" data-action="customer-add" aria-label="Ongeza mteja">＋</button>`;
}

// Hufungua fomu ya kuongeza au kuhariri taarifa za mteja.
async function openCustomerForm(id = "") {
  const customer = id ? (await getAll("customers")).find(item => item.id === id) : null;
  if (id && !customer) return notify("Mteja huyu hapatikani.", true);
  const item = customer || { name: "", phone: "", area: "", service: "halotel", source: "mtaani", status: "Mpya", followUpDate: "", notes: "" };
  const services = [{ value: "halotel", label: "Halotel" }, { value: "tigo", label: "Tigo Fibre" }, { value: "zote", label: "Zote" }];
  const sources = ["mtaani", "referral", "WhatsApp", "social media", "nyingine"].map(value => ({ value, label: value }));
  showModal(customer ? "Hariri mteja" : "Mteja mpya", `<form data-form="customer" data-id="${customer?.id || ""}">
    <div class="form-grid two-col">
      <div class="field"><label for="customer-name">Jina *</label><input id="customer-name" name="name" required autocomplete="name" value="${escapeHTML(item.name)}" placeholder="Mfano: Asha Juma"></div>
      <div class="field"><label for="customer-phone">Namba ya simu *</label><input id="customer-phone" name="phone" required inputmode="tel" value="${escapeHTML(item.phone)}" placeholder="07XX XXX XXX"><span class="field-hint">Tumia namba inayoanza 07, 06 au 255.</span></div>
      <div class="field"><label for="customer-area">Eneo / mtaa</label><input id="customer-area" name="area" value="${escapeHTML(item.area)}" placeholder="Mfano: Sinza"></div>
      <div class="field"><label for="customer-service">Huduma</label><select id="customer-service" name="service">${options(services, item.service)}</select></div>
      <div class="field"><label for="customer-source">Chanzo</label><select id="customer-source" name="source">${options(sources, item.source)}</select></div>
      <div class="field"><label for="customer-status">Hatua</label><select id="customer-status" name="status">${statusOptions(item.status)}</select></div>
      <div class="field"><label for="customer-followup">Tarehe ya ufuatiliaji</label><input id="customer-followup" name="followUpDate" type="date" value="${escapeHTML(item.followUpDate || "")}"></div>
      <div class="field"><label for="customer-notes">Maelezo</label><textarea id="customer-notes" name="notes" placeholder="Maelezo mafupi...">${escapeHTML(item.notes || "")}</textarea></div>
    </div><div class="form-actions"><button type="button" class="button button-secondary" data-action="close-modal">Ghairi</button><button class="button button-primary">Hifadhi mteja</button></div>
    ${customer ? `<button type="button" class="button button-danger" style="width:100%;margin-top:9px" data-action="customer-delete" data-id="${customer.id}">Futa mteja</button>` : ""}</form>`);
}

// Huonyesha maelezo na ratiba ya dokezo la mteja.
async function viewCustomer(id) {
  const customer = (await getAll("customers")).find(item => item.id === id);
  if (!customer) return notify("Mteja huyu hapatikani.", true);
  const notes = customer.notesTimeline || [];
  showModal(customer.name, `<p class="muted">${escapeHTML(customer.phone)} · ${escapeHTML(customer.area || "Eneo halijatajwa")} · ${escapeHTML(serviceName(customer.service))}</p>
    <form data-form="customer-note" data-id="${customer.id}"><div class="field"><label for="note-text">Ongeza dokezo la mawasiliano</label><textarea id="note-text" name="text" required placeholder="Umezungumza nini na mteja?"></textarea></div><button class="button button-primary" style="width:100%;margin-top:9px">Hifadhi dokezo</button></form>
    <div class="section-heading"><h2>Historia ya mawasiliano</h2></div>
    ${notes.length ? `<div class="timeline">${notes.map(note => `<div class="note-item">${escapeHTML(note.text)}<time>${new Date(note.date).toLocaleString("sw-TZ")}</time></div>`).join("")}</div>` : emptyState("Hakuna dokezo bado", "Dokezo utakaloandika litaonekana hapa.")}`);
}

// Huchora orodha ya mauzo na fomu ya kuingiza mauzo mapya.
async function renderSales() {
  const [sales, customers] = await Promise.all([getAll("sales"), getAll("customers")]);
  const customerNames = new Map(customers.map(item => [item.id, item.name]));
  const ordered = [...sales].sort((a, b) => b.date.localeCompare(a.date));
  main.innerHTML = `<h1 class="page-title">Mauzo</h1><p class="page-subtitle">Rekodi mauzo yako na ufuatilie kamisheni pamoja na ufungaji.</p>
    <button class="button button-primary" data-action="sale-add" style="width:100%;margin-bottom:18px">＋ Rekodi mauzo</button>
    <div class="table-list">${ordered.length ? ordered.map(sale => `<article class="row-item"><div style="min-width:0"><div class="row-title">${escapeHTML(sale.bundle)} · ${escapeHTML(customerNames.get(sale.customerId) || "Mteja amefutwa")}</div><div class="row-meta">${escapeHTML(serviceName(sale.service))} · ${escapeHTML(sale.date)}${sale.service === "tigo" ? ` · <select class="control installation-select" data-action="installation-change" data-id="${sale.id}">${options(["Inasubiri", "Imewekwa", "Imekwama"].map(value => ({ value, label: value })), sale.installation)}</select>` : ""}</div><div class="row-meta">Kamisheni: ${money(sale.commission)}</div></div><div class="row-amount positive">${money(sale.amount)}<button class="icon-button" data-action="sale-delete" data-id="${sale.id}" aria-label="Futa mauzo" title="Futa mauzo">×</button></div></article>`).join("") : emptyState("Bado hakuna mauzo", "Mauzo yako yakirekodiwa, kamisheni itahesabiwa moja kwa moja.", customers.length ? '<button class="button button-primary" data-action="sale-add">Rekodi mauzo</button>' : '<button class="button button-secondary" data-page-link="customers">Ongeza mteja kwanza</button>')}</div>`;
}

// Hufungua fomu ya kurekodi mauzo kwa mteja aliyechaguliwa.
async function openSaleForm() {
  const customers = await getAll("customers");
  if (!customers.length) return notify("Ongeza mteja kabla ya kurekodi mauzo.", true);
  const customerOptions = customers.map(customer => ({ value: customer.id, label: `${customer.name} · ${customer.phone}` }));
  showModal("Rekodi mauzo", `<form data-form="sale"><div class="form-grid two-col">
    <div class="field"><label for="sale-customer">Mteja *</label><select id="sale-customer" name="customerId" required>${options(customerOptions)}</select></div>
    <div class="field"><label for="sale-service">Huduma</label><select id="sale-service" name="service"><option value="halotel">Halotel</option><option value="tigo">Tigo Fibre</option></select></div>
    <div class="field"><label for="sale-bundle">Kifurushi / huduma *</label><input id="sale-bundle" name="bundle" required placeholder="Mfano: Bando la GB 10"></div>
    <div class="field"><label for="sale-amount">Kiasi cha mauzo (TSh) *</label><input id="sale-amount" name="amount" type="number" min="1" step="1" required inputmode="numeric" placeholder="25000"></div>
    <div class="field"><label for="sale-date">Tarehe</label><input id="sale-date" name="date" type="date" value="${localDate()}"></div>
    <div class="field" id="installation-field" hidden><label for="sale-installation">Hali ya ufungaji</label><select id="sale-installation" name="installation"><option>Inasubiri</option><option>Imewekwa</option><option>Imekwama</option></select></div>
    </div><div class="form-actions"><button type="button" class="button button-secondary" data-action="close-modal">Ghairi</button><button class="button button-primary">Hifadhi mauzo</button></div></form>`);
  const serviceSelect = modalRoot.querySelector("#sale-service");
  serviceSelect.addEventListener("change", () => { modalRoot.querySelector("#installation-field").hidden = serviceSelect.value !== "tigo"; });
}

// Huonyesha muhtasari wa fedha kwa leo, wiki, mwezi au tarehe maalumu.
async function renderFinance() {
  const today = localDate();
  let start, end;
  if (state.financeRange === "today") start = end = today;
  else if (state.financeRange === "week") [start, end] = currentWeekRange(new Date());
  else if (state.financeRange === "custom") { start = state.financeStart; end = state.financeEnd; }
  else { start = `${today.slice(0, 7)}-01`; end = today; }
  const summary = await getFinanceSummary(start, end);
  const rangeLabel = state.financeRange === "today" ? "Leo" : state.financeRange === "week" ? "Wiki hii" : state.financeRange === "custom" ? "Kipindi ulichochagua" : "Mwezi huu";
  const entries = [
    ...summary.sales.map(item => ({ date: item.date, name: item.bundle, sub: `${serviceName(item.service)} · Kamisheni ${money(item.commission)}`, amount: item.commission, type: "commission", id: item.id })),
    ...summary.expenses.map(item => ({ date: item.date, name: item.description || item.category, sub: `Matumizi · ${item.category}`, amount: item.amount, type: "expense", id: item.id }))
  ].sort((a, b) => b.date.localeCompare(a.date));
  main.innerHTML = `<h1 class="page-title">Fedha</h1><p class="page-subtitle">Jua kamisheni, matumizi na faida yako halisi.</p>
    <div class="subnav">${[["today", "Leo"], ["week", "Wiki hii"], ["month", "Mwezi huu"], ["custom", "Tarehe"]].map(([key, label]) => `<button class="${state.financeRange === key ? "active" : ""}" data-range="${key}">${label}</button>`).join("")}</div>
    ${state.financeRange === "custom" ? `<div class="filter-row" style="margin-bottom:12px"><input class="control" type="date" data-finance-date="start" value="${escapeHTML(state.financeStart)}" aria-label="Kuanzia tarehe"><input class="control" type="date" data-finance-date="end" value="${escapeHTML(state.financeEnd)}" aria-label="Mpaka tarehe"></div>` : ""}
    <div class="grid stats-grid"><article class="stat-card"><div class="stat-label">Kamisheni · ${rangeLabel}</div><div class="stat-value">${money(summary.commission)}</div></article><article class="stat-card"><div class="stat-label">Matumizi · ${rangeLabel}</div><div class="stat-value">${money(summary.spending)}</div></article><article class="stat-card"><div class="stat-label">Faida</div><div class="stat-value" style="color:${summary.profit < 0 ? "var(--danger)" : "var(--green)"}">${money(summary.profit)}</div></article></div>
    <div class="section-heading"><h2>Matumizi</h2><button class="button button-primary button-small" data-action="expense-add">＋ Ongeza matumizi</button></div>
    <div class="table-list">${entries.length ? entries.map(item => `<article class="row-item"><div><div class="row-title">${escapeHTML(item.name)}</div><div class="row-meta">${escapeHTML(item.sub)} · ${escapeHTML(item.date)}</div></div><div class="row-amount ${item.type === "commission" ? "positive" : "negative"}">${item.type === "commission" ? "+" : "−"}${money(item.amount)}${item.type === "expense" ? `<button class="icon-button" data-action="expense-delete" data-id="${item.id}" aria-label="Futa matumizi">×</button>` : ""}</div></article>`).join("") : emptyState("Hakuna rekodi za fedha", "Rekodi mauzo au ongeza matumizi ili kuona muhtasari.")}</div>`;
}

// Hufungua fomu ya kuingiza matumizi ya biashara.
function openExpenseForm() {
  showModal("Ongeza matumizi", `<form data-form="expense"><div class="form-grid two-col">
    <div class="field"><label for="expense-category">Aina ya matumizi *</label><select id="expense-category" name="category">${options(EXPENSE_TYPES.map(value => ({ value, label: value })))}</select></div>
    <div class="field"><label for="expense-amount">Kiasi (TSh) *</label><input id="expense-amount" name="amount" type="number" min="1" step="1" required inputmode="numeric" placeholder="5000"></div>
    <div class="field"><label for="expense-date">Tarehe</label><input id="expense-date" name="date" type="date" value="${localDate()}"></div>
    <div class="field"><label for="expense-description">Maelezo</label><input id="expense-description" name="description" placeholder="Mfano: Nauli ya kwenda kwa mteja"></div>
    </div><div class="form-actions"><button type="button" class="button button-secondary" data-action="close-modal">Ghairi</button><button class="button button-primary">Hifadhi matumizi</button></div></form>`);
}

// Huchora mipangilio, uingizaji wa data na maarifa ya maeneo.
async function renderMore() {
  const [customers, sales, expenses] = await Promise.all([getAll("customers"), getAll("sales"), getAll("expenses")]);
  const areas = new Map();
  for (const customer of customers) {
    const key = customer.area || "Eneo halijatajwa";
    const item = areas.get(key) || { name: key, leads: 0, sales: 0, amount: 0 };
    item.leads++;
    const ownSales = sales.filter(sale => sale.customerId === customer.id);
    item.sales += ownSales.length;
    item.amount += ownSales.reduce((sum, sale) => sum + Number(sale.amount || 0), 0);
    areas.set(key, item);
  }
  const rankings = [...areas.values()].sort((a, b) => b.amount - a.amount);
  const opportunities = rankings.filter(area => area.leads >= 2 && area.sales / area.leads < .35).sort((a, b) => (b.leads - b.sales) - (a.leads - a.sales));
  main.innerHTML = `<h1 class="page-title">Zaidi</h1><p class="page-subtitle">Mipangilio, taarifa na fursa za kukuza biashara.</p>
    <div class="more-grid">
      <section class="setting-tile"><h3>⚙ Mipangilio ya biashara</h3><p>Kamisheni, lengo la mwezi na ujumbe wa WhatsApp.</p><button class="button button-secondary button-small" data-action="settings-open">Fungua mipangilio</button></section>
      <section class="setting-tile"><h3>🔔 Vikumbusho</h3><p>Ruhusu arifa za ufuatiliaji unapokuwa kwenye programu.</p><button class="button button-secondary button-small" data-action="notifications-enable">Washa vikumbusho</button><span class="field-hint" id="notification-status">${"Notification" in window && Notification.permission === "granted" ? "Arifa zimewashwa." : ""}</span></section>
      <section class="setting-tile"><h3>⬇ Hifadhi na toa data</h3><p>Pakua CSV au nakala kamili ya taarifa zako.</p><div class="inline-actions"><button class="button button-secondary button-small" data-action="export-customers">Pakua wateja CSV</button><button class="button button-secondary button-small" data-action="export-sales">Pakua mauzo CSV</button><button class="button button-secondary button-small" data-action="export-expenses">Pakua matumizi CSV</button><button class="button button-primary button-small" data-action="backup-export">Nakala kamili JSON</button></div></section>
      <section class="setting-tile"><h3>⬆ Ingiza data</h3><p>Ingiza wateja kutoka CSV au rejesha nakala ya JSON.</p><div class="inline-actions"><button class="button button-secondary button-small" data-action="import-csv">Ingiza wateja CSV</button><button class="button button-secondary button-small" data-action="backup-import">Rejesha nakala JSON</button></div><input class="csv-file" id="csv-input" type="file" accept=".csv,text/csv"><input class="csv-file" id="json-input" type="file" accept=".json,application/json"></section>
      <section class="setting-tile"><h3>✨ Jaribu programu</h3><p>Ongeza wateja 10 na mauzo 5 ya mfano ili uone jinsi mfumo unavyofanya kazi.</p><button class="button button-primary button-small" data-action="sample-add">Weka data za mfano</button><button class="button button-secondary button-small" data-action="sample-remove">Ondoa data za mfano</button></section>
      <section class="setting-tile"><h3>📍 Maeneo na fursa</h3><p>Maeneo yenye mauzo mengi na sehemu zinazohitaji ufuatiliaji.</p>
        <div class="section-heading"><h2>Maeneo bora kwa mauzo</h2></div>${rankings.length ? `<div class="table-list">${rankings.map((area, index) => `<article class="row-item"><div><div class="row-title">${index + 1}. ${escapeHTML(area.name)}</div><div class="row-meta">${area.leads} wateja · ${area.sales} mauzo</div></div><div class="row-amount positive">${money(area.amount)}</div></article>`).join("")}</div>` : emptyState("Bado hakuna data ya maeneo", "Weka eneo kwa wateja na urekodi mauzo.")}
        <div class="section-heading"><h2>Fursa za kufuatilia</h2></div>${opportunities.length ? `<div class="table-list">${opportunities.map(area => `<article class="row-item"><div><div class="row-title">💡 ${escapeHTML(area.name)}</div><div class="row-meta">${area.leads} wateja lakini mauzo ${area.sales} tu. Tembelea eneo hili.</div></div><span class="badge status-anafikiria">Fursa</span></article>`).join("")}</div>` : emptyState("Hakuna fursa maalumu kwa sasa", "Ongeza wateja katika maeneo mapya ili kuona fursa.")}</section>
      <section class="setting-tile"><h3>🔐 Faragha ya programu</h3><p>Weka PIN ya tarakimu nne inayohifadhiwa kama hash kwenye kifaa hiki.</p><button class="button button-secondary button-small" data-action="pin-setup">${state.settings.pinHash ? "Badili au ondoa PIN" : "Weka PIN"}</button></section>
      <section class="setting-tile"><h3>⚠ Eneo la hatari</h3><p>Futa kabisa wateja, mauzo, matumizi na mipangilio iliyohifadhiwa kwenye kifaa.</p><button class="button button-danger button-small" data-action="clear-data">Futa data zote</button></section>
    </div>`;
}

// Hufungua fomu ya mipangilio ya viwango na ujumbe wa huduma.
function openSettingsForm() {
  const settings = state.settings;
  const fieldFor = (service, label) => {
    const rate = settings.commission[service];
    return `<fieldset class="card" style="padding:12px"><legend>${label}</legend><div class="form-grid two-col"><div class="field"><label>Kiasi cha kamisheni</label><input name="${service}Value" type="number" min="0" step="any" value="${escapeHTML(rate.value)}" required></div><div class="field"><label>Aina</label><select name="${service}Mode"><option value="percent" ${rate.mode === "percent" ? "selected" : ""}>Asilimia (%)</option><option value="fixed" ${rate.mode === "fixed" ? "selected" : ""}>Kiasi maalumu (TSh)</option></select></div></div></fieldset>`;
  };
  showModal("Mipangilio ya biashara", `<form data-form="settings">
    <div class="field"><label for="target-value">Lengo la kamisheni kwa mwezi (TSh)</label><input id="target-value" name="monthlyTarget" type="number" min="0" step="1" value="${escapeHTML(settings.monthlyTarget)}"></div>
    <div class="section-heading"><h2>Viwango vya kamisheni</h2></div>${fieldFor("halotel", "Halotel")}${fieldFor("tigo", "Tigo Fibre")}
    <div class="section-heading"><h2>Ujumbe wa WhatsApp</h2></div><div class="field"><label for="template-halotel">Ujumbe wa Halotel</label><textarea id="template-halotel" name="templateHalotel">${escapeHTML(settings.templates.halotel)}</textarea><span class="field-hint">Tumia {jina} ili kuweka jina la mteja.</span></div>
    <div class="field" style="margin-top:12px"><label for="template-tigo">Ujumbe wa Tigo Fibre</label><textarea id="template-tigo" name="templateTigo">${escapeHTML(settings.templates.tigo)}</textarea><span class="field-hint">Tumia {jina} ili kuweka jina la mteja.</span></div>
    <div class="form-actions"><button type="button" class="button button-secondary" data-action="close-modal">Ghairi</button><button class="button button-primary">Hifadhi mipangilio</button></div>
    </form>`);
}

// Hufungua PIN ya kufunga programu au kubadilisha PIN iliyopo.
function openPinSetup() {
  showModal("PIN ya programu", `<form data-form="pin"><p class="muted">${state.settings.pinHash ? "Weka PIN mpya au acha tupu ili kuondoa PIN." : "Weka tarakimu nne za kufungua programu hii."}</p><div class="field"><label for="pin-new">PIN mpya</label><input id="pin-new" name="pin" inputmode="numeric" maxlength="4" pattern="[0-9]{4}" autocomplete="new-password" placeholder="••••"></div><div class="form-actions"><button type="button" class="button button-secondary" data-action="close-modal">Ghairi</button><button class="button button-primary">Hifadhi PIN</button></div></form>`);
}

// Huomba ruhusa ya arifa baada ya mtumiaji kubonyeza kitufe.
async function enableNotifications() {
  if (!("Notification" in window)) return notify("Kifaa hiki hakiungi mkono arifa za kivinjari.", true);
  const permission = await Notification.requestPermission();
  state.settings.notificationsAsked = true;
  await saveSettings(state.settings);
  if (permission === "granted") {
    notify("Vikumbusho vimewashwa. Tutakukumbusha ukiwa kwenye programu.");
    await checkReminders();
  } else notify("Ruhusa ya arifa haikuwashwa. Unaweza kuibadili kwenye mipangilio ya kivinjari.", true);
  render();
}

// Hutuma arifa kwa wateja ambao muda wao wa kufuatilia umefika.
async function checkReminders() {
  if (!("Notification" in window) || Notification.permission !== "granted") return;
  const today = localDate();
  const customers = await getAll("customers");
  const due = customers.filter(item => item.followUpDate && item.followUpDate <= today && !["Nimefunga", "Amekataa"].includes(item.status));
  if (due.length) new Notification("Wakala Pro · Ufuatiliaji", { body: `Una wateja ${due.length} wa kufuatilia leo au ambao wamechelewa.` });
}

// Huweka sampuli za wateja 10 na mauzo 5 kwa majaribio ya programu.
async function addSampleData() {
  const customers = await getAll("customers");
  if (customers.some(item => item.isSample)) return notify("Data za mfano tayari zimewekwa.");
  const names = ["Asha Juma", "Baraka Ally", "Neema Mushi", "Juma Salum", "Rehema Paulo", "Daudi Joseph", "Upendo John", "Hassan Omari", "Zawadi Peter", "Mariam Said"];
  const areas = ["Sinza", "Kinondoni", "Mbezi", "Tegeta", "Ubungo", "Sinza", "Mbagala", "Kimara", "Kinondoni", "Tegeta"];
  const sampleCustomers = [];
  const usedPhones = new Set(customers.map(customer => normalizePhone(customer.phone)).filter(Boolean));
  let nextPhone = 10000000;
  for (let index = 0; index < names.length; index++) {
    let phone;
    do { phone = normalizePhone(`07${String(nextPhone++)}`); } while (usedPhones.has(phone));
    usedPhones.add(phone);
    const customer = await saveCustomer({
      name: names[index], phone, area: areas[index],
      service: index % 2 ? "tigo" : "halotel", source: ["mtaani", "referral", "WhatsApp", "social media", "nyingine"][index % 5],
      status: index < 5 ? "Nimefunga" : CUSTOMER_STATUSES[index % 3], followUpDate: index === 7 ? localDate() : "",
      notes: "Mteja wa mfano", isSample: true
    });
    sampleCustomers.push(customer);
  }
  for (let index = 0; index < 5; index++) {
    const date = new Date(); date.setDate(date.getDate() - (4 - index));
    const sale = await saveSale({ customerId: sampleCustomers[index].id, service: index % 2 ? "tigo" : "halotel", bundle: index % 2 ? "Tigo Fibre Home" : "Bando la intaneti", amount: [35000, 120000, 25000, 90000, 50000][index], date: localDate(date), installation: index % 2 ? "Imewekwa" : "" }, state.settings);
    sale.isSample = true; await put("sales", sale);
  }
  notify("Data 10 za wateja na mauzo 5 zimeongezwa.");
  render();
}

// Huondoa rekodi zote zilizowekwa kama sampuli pekee.
async function removeSampleData() {
  const [customers, sales, expenses] = await Promise.all([getAll("customers"), getAll("sales"), getAll("expenses")]);
  for (const sale of sales.filter(item => item.isSample)) await deleteSale(sale.id);
  for (const expense of expenses.filter(item => item.isSample)) await deleteExpense(expense.id);
  for (const customer of customers.filter(item => item.isSample)) await deleteCustomer(customer.id);
  if (!customers.some(item => item.isSample)) return notify("Hakuna data za mfano za kuondoa.");
  notify("Data za mfano zimeondolewa.");
  render();
}

// Huanzisha upakuaji wa nakala kamili ya JSON.
async function downloadBackup() {
  const data = await exportBackup();
  const url = URL.createObjectURL(new Blob([JSON.stringify(data, null, 2)], { type: "application/json" }));
  const link = document.createElement("a");
  link.href = url; link.download = `wakala-pro-nakala-${localDate()}.json`; link.click();
  URL.revokeObjectURL(url);
  notify("Nakala ya data imepakuliwa.");
}

// Hubadilisha CSV kuwa wateja na kuripoti zilizokubaliwa au kurudiwa.
async function importCustomersCSV(file) {
  const records = parseCSV(await file.text());
  let added = 0, skipped = 0;
  for (const record of records) {
    try {
      const service = (record.huduma || record.service || "").toLowerCase();
      await saveCustomer({
        name: record.jina || record.name, phone: record.simu || record.phone, area: record.eneo || record.area,
        service: service.includes("tigo") ? "tigo" : service.includes("zote") ? "zote" : "halotel",
        source: record.chanzo || record.source || "nyingine", status: record.hatua || record.status || "Mpya",
        notes: record.maelezo || record.notes || "", followUpDate: record.ufuataliaji || record.followup || ""
      });
      added++;
    } catch (error) {
      if (error instanceof Error && /^(Tafadhali weka jina|Namba si sahihi|Namba hii tayari|Huduma ya mteja|Hatua ya mteja)/.test(error.message)) skipped++;
      else throw error;
    }
  }
  notify(`Wateja ${added} wameingizwa${skipped ? `; ${skipped} hawakuweza kuingizwa` : ""}.`, skipped > 0);
  render();
}

// Hushughulikia vitufe, viungo na vitendo vya orodha.
async function handleAction(action, element) {
  const id = element.dataset.id;
  if (action === "close-modal") closeModal();
  else if (action === "customer-add") await openCustomerForm();
  else if (action === "customer-edit") await openCustomerForm(id);
  else if (action === "customer-view") await viewCustomer(id);
  else if (action === "customer-delete") {
    if (confirm("Una uhakika unataka kumfuta mteja huyu? Mauzo yake yaliyorekodiwa yatabaki.")) {
      await deleteCustomer(id); closeModal(); notify("Mteja amefutwa."); render();
    }
  } else if (action === "sale-add") await openSaleForm();
  else if (action === "expense-add") openExpenseForm();
  else if (action === "sale-delete") {
    if (confirm("Futa rekodi hii ya mauzo?")) { await deleteSale(id); notify("Mauzo yamefutwa."); render(); }
  } else if (action === "expense-delete") {
    if (confirm("Futa rekodi hii ya matumizi?")) { await deleteExpense(id); notify("Matumizi yamefutwa."); render(); }
  } else if (action === "settings-open") openSettingsForm();
  else if (action === "pin-setup") openPinSetup();
  else if (action === "notifications-enable") await enableNotifications();
  else if (action === "sample-add") await addSampleData();
  else if (action === "sample-remove") await removeSampleData();
  else if (action === "backup-export") await downloadBackup();
  else if (action === "backup-import") document.querySelector("#json-input").click();
  else if (action === "import-csv") document.querySelector("#csv-input").click();
  else if (action === "clear-data") {
    if (confirm("Tahadhari: data zote zitafutwa kabisa kwenye kifaa hiki. Endelea?") && confirm("Thibitisha mara ya pili: huna nakala au uko tayari kupoteza data zote?")) {
      await clearAllData(); state.settings = await getSettings(); notify("Data zote zimefutwa."); setPage("home");
    }
  } else if (action.startsWith("export-")) await exportCSVAction(action);
}

// Hupakua CSV ya aina ya data iliyochaguliwa.
async function exportCSVAction(action) {
  if (action === "export-customers") {
    const records = await getAll("customers");
    downloadCSV("wakala-pro-wateja.csv", [["Jina", "Simu", "Eneo", "Huduma", "Chanzo", "Hatua", "Tarehe ya kuongezwa", "Ufuatiliaji", "Maelezo"], ...records.map(item => [item.name, item.phone, item.area, serviceName(item.service), item.source, item.status, item.createdAt, item.followUpDate, item.notes])]);
  } else if (action === "export-sales") {
    const records = await getAll("sales");
    const customers = new Map((await getAll("customers")).map(item => [item.id, item]));
    downloadCSV("wakala-pro-mauzo.csv", [["Mteja", "Simu", "Huduma", "Kifurushi", "Kiasi", "Kamisheni", "Tarehe", "Ufungaji"], ...records.map(item => {
      const customer = customers.get(item.customerId);
      return [customer?.name || "Mteja amefutwa", customer?.phone || "", serviceName(item.service), item.bundle, item.amount, item.commission, item.date, item.installation];
    })]);
  } else {
    const records = await getAll("expenses");
    downloadCSV("wakala-pro-matumizi.csv", [["Aina", "Maelezo", "Kiasi", "Tarehe"], ...records.map(item => [item.category, item.description, item.amount, item.date])]);
  }
  notify("Faili la CSV limepakuliwa.");
}

// Huhifadhi fomu zote na kuonyesha makosa rafiki kwa Kiswahili.
async function handleSubmit(form) {
  const data = Object.fromEntries(new FormData(form).entries());
  const id = form.dataset.id;
  if (form.dataset.form === "customer") {
    await saveCustomer({ ...data, id: id || undefined, status: data.status || "Mpya" });
    closeModal(); notify(id ? "Taarifa za mteja zimesasishwa." : "Mteja amehifadhiwa."); await render();
  } else if (form.dataset.form === "customer-note") {
    await addCustomerNote(id, data.text); await viewCustomer(id); notify("Dokezo limehifadhiwa.");
  } else if (form.dataset.form === "sale") {
    const saved = await saveSale(data, state.settings);
    closeModal(); notify(`Mauzo yamehifadhiwa. Kamisheni: ${money(saved.commission)}`); await render();
  } else if (form.dataset.form === "expense") {
    await saveExpense(data); closeModal(); notify("Matumizi yamehifadhiwa."); await render();
  } else if (form.dataset.form === "settings") {
    state.settings.monthlyTarget = Number(data.monthlyTarget || 0);
    state.settings.commission = { halotel: { mode: data.halotelMode, value: Number(data.halotelValue) }, tigo: { mode: data.tigoMode, value: Number(data.tigoValue) } };
    state.settings.templates = { halotel: data.templateHalotel, tigo: data.templateTigo };
    await saveSettings(state.settings); closeModal(); notify("Mipangilio imehifadhiwa."); await render();
  } else if (form.dataset.form === "pin") {
    if (!data.pin && !state.settings.pinHash) throw new Error("Weka PIN ya tarakimu nne.");
    state.settings.pinHash = data.pin ? await hashPin(data.pin) : "";
    await saveSettings(state.settings); closeModal(); notify(state.settings.pinHash ? "PIN imewekwa." : "PIN imeondolewa.");
  } else if (form.dataset.form === "unlock") {
    const hash = await hashPin(data.pin);
    if (hash !== state.settings.pinHash) throw new Error("PIN si sahihi. Jaribu tena.");
    state.authenticated = true; closeModal(); await render();
  }
}

// Hufunga programu kwa PIN mara tu inapofunguliwa ikiwa imewekwa.
function requestPinUnlock() {
  if (!state.settings.pinHash || state.authenticated) return;
  showModal("Fungua Wakala Pro", `<form data-form="unlock"><p class="muted">Weka PIN yako ya tarakimu nne ili kufungua taarifa zako.</p><div class="field"><label for="pin-unlock">PIN</label><input id="pin-unlock" name="pin" type="password" inputmode="numeric" maxlength="4" pattern="[0-9]{4}" required autocomplete="current-password"></div><button class="button button-primary" style="width:100%;margin-top:14px">Fungua programu</button></form>`);
}

// Husikiliza vitendo na fomu kwa kutumia event delegation.
document.addEventListener("click", async event => {
  const nav = event.target.closest("[data-page]");
  if (nav) { event.preventDefault(); setPage(nav.dataset.page); return; }
  const pageLink = event.target.closest("[data-page-link]");
  if (pageLink) { event.preventDefault(); setPage(pageLink.dataset.pageLink); return; }
  const range = event.target.closest("[data-range]");
  if (range) { state.financeRange = range.dataset.range; if (state.financeRange === "custom" && !state.financeStart) state.financeStart = `${localDate().slice(0, 7)}-01`; if (state.financeRange === "custom" && !state.financeEnd) state.financeEnd = localDate(); render(); return; }
  const actionElement = event.target.closest("[data-action]");
  if (actionElement && actionElement.dataset.action !== "status-change" && actionElement.dataset.action !== "installation-change") {
    try { await handleAction(actionElement.dataset.action, actionElement); } catch (error) { notify(error.message || "Imeshindikana kufanya kitendo hiki.", true); }
  }
});

// Huhifadhi data za fomu zote kwa njia moja na kutunza ujumbe wa kosa.
document.addEventListener("submit", async event => {
  const form = event.target.closest("form[data-form]");
  if (!form) return;
  event.preventDefault();
  const button = form.querySelector('button[type="submit"],button:not([type])');
  if (button) button.disabled = true;
  try { await handleSubmit(form); } catch (error) { notify(error.message || "Tafadhali kagua taarifa ulizoingiza.", true); }
  finally { if (button?.isConnected) button.disabled = false; }
});

// Hushughulikia utafutaji na uchujaji wa wateja bila kupoteza maandishi.
document.addEventListener("input", event => {
  if (event.target.matches("[data-filter='search']")) {
    state.filter.search = event.target.value;
    const start = event.target.selectionStart;
    render().then(() => { const input = main.querySelector("[data-filter='search']"); input?.focus(); input?.setSelectionRange(start, start); });
  }
});

// Husikiliza mabadiliko ya hali ya mteja na ufungaji wa Tigo Fibre.
document.addEventListener("change", async event => {
  const target = event.target;
  try {
    if (target.matches("[data-filter]") && target.dataset.filter !== "search") {
      state.filter[target.dataset.filter] = target.value; await render();
    } else if (target.matches("[data-finance-date]")) {
      state[target.dataset.financeDate === "start" ? "financeStart" : "financeEnd"] = target.value;
      await render();
    } else if (target.dataset.action === "status-change") {
      await changeCustomerStatus(target.dataset.id, target.value); notify("Hatua ya mteja imesasishwa.");
    } else if (target.dataset.action === "installation-change") {
      await updateInstallation(target.dataset.id, target.value); notify("Hali ya ufungaji imesasishwa.");
    } else if (target.id === "json-input" && target.files[0]) {
      const file = target.files[0];
      if (!confirm("Kurejesha nakala kutafuta na kubadilisha taarifa zilizopo. Endelea?")) { target.value = ""; return; }
      const backup = JSON.parse(await file.text()); await importDatabase(backup); state.settings = await getSettings(); target.value = ""; notify("Nakala imerejeshwa."); render();
    } else if (target.id === "csv-input" && target.files[0]) {
      await importCustomersCSV(target.files[0]); target.value = "";
    }
  } catch (error) { notify(error.message || "Imeshindikana kusasisha taarifa.", true); }
});

// Hubadilisha hali ya mwanga na giza na kukumbuka chaguo la mtumiaji.
document.querySelector("#theme-toggle").addEventListener("click", () => {
  document.body.classList.toggle("dark");
  localStorage.setItem("wakala-theme", document.body.classList.contains("dark") ? "dark" : "light");
});
if (localStorage.getItem("wakala-theme") === "dark") document.body.classList.add("dark");
document.querySelector("#quick-add").addEventListener("click", () => openCustomerForm().catch(error => notify(error.message, true)));

// Husajili service worker ili kuhifadhi app na kuifungua bila intaneti.
if ("serviceWorker" in navigator) {
  window.addEventListener("load", () => navigator.serviceWorker.register("./sw.js").catch(error => console.error("Service worker haikusajiliwa:", error)));
}

// Huanzisha programu kwa kufungua hifadhi na kuangalia vikumbusho.
async function startApp() {
  try {
    state.settings = await getSettings();
    await render();
    requestPinUnlock();
    await checkReminders();
  } catch (error) {
    main.innerHTML = emptyState("Imeshindikana kuanza", escapeHTML(error.message || "Hifadhi ya kifaa haipatikani."));
  }
}
startApp();
