import { getAll, put, remove, createId } from "./db.js";

export const EXPENSE_TYPES = ["Usafiri", "Vocha", "Data", "Matangazo", "Mengineyo"];

// Huhifadhi matumizi baada ya kuthibitisha kiasi na aina yake.
export async function saveExpense(expense) {
  const amount = Number(expense.amount);
  if (!Number.isFinite(amount) || amount <= 0) throw new Error("Kiasi cha matumizi lazima kiwe zaidi ya sifuri.");
  if (!EXPENSE_TYPES.includes(expense.category)) throw new Error("Chagua aina sahihi ya matumizi.");
  const saved = { ...expense, id: expense.id || createId(), amount, date: expense.date || new Date().toISOString().slice(0, 10), createdAt: expense.createdAt || new Date().toISOString() };
  await put("expenses", saved);
  return saved;
}

// Huondoa matumizi kwa kitambulisho chake.
export const deleteExpense = id => remove("expenses", id);

// Huchuja rekodi za fedha kwa kipindi kilichochaguliwa.
export function inDateRange(date, start, end) {
  return (!start || date >= start) && (!end || date <= end);
}

// Hutoa jumla ya mauzo, kamisheni na matumizi katika muda husika.
export async function getFinanceSummary(start, end) {
  const [sales, expenses] = await Promise.all([getAll("sales"), getAll("expenses")]);
  const selectedSales = sales.filter(item => inDateRange(item.date, start, end));
  const selectedExpenses = expenses.filter(item => inDateRange(item.date, start, end));
  const commission = selectedSales.reduce((sum, item) => sum + Number(item.commission || 0), 0);
  const spending = selectedExpenses.reduce((sum, item) => sum + Number(item.amount || 0), 0);
  return { sales: selectedSales, expenses: selectedExpenses, commission, spending, profit: commission - spending };
}
