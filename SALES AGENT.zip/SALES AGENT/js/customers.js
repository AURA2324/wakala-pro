import { getAll, put, remove, createId } from "./db.js";

export const CUSTOMER_STATUSES = ["Mpya", "Nimewasiliana", "Anafikiria", "Nimefunga", "Amekataa"];
export const SERVICES = { halotel: "Halotel", tigo: "Tigo Fibre", zote: "Zote" };

// Husafisha na kuthibitisha namba za simu za Tanzania.
export function normalizePhone(phone) {
  const digits = String(phone || "").replace(/\D/g, "");
  if (/^0[67]\d{8}$/.test(digits)) return `255${digits.slice(1)}`;
  if (/^255[67]\d{8}$/.test(digits)) return digits;
  if (/^[67]\d{8}$/.test(digits)) return `255${digits}`;
  return "";
}

// Huhakikisha jina, simu na sehemu muhimu zimejazwa kwa usahihi.
export function validateCustomer(customer) {
  if (!customer.name?.trim()) throw new Error("Tafadhali weka jina la mteja.");
  const phone = normalizePhone(customer.phone);
  if (!phone) throw new Error("Namba si sahihi. Tumia 07xx, 06xx au 255...");
  if (!Object.hasOwn(SERVICES, customer.service || "halotel")) throw new Error("Huduma ya mteja si sahihi.");
  if (!CUSTOMER_STATUSES.includes(customer.status || "Mpya")) throw new Error("Hatua ya mteja si sahihi.");
  return { ...customer, name: customer.name.trim(), phone, area: customer.area?.trim() || "", notes: customer.notes?.trim() || "" };
}

// Huhifadhi mteja na kuzuia namba ya simu kujirudia.
export async function saveCustomer(customer) {
  const checked = validateCustomer(customer);
  const customers = await getAll("customers");
  const duplicate = customers.find(item => item.phone === checked.phone && item.id !== checked.id);
  if (duplicate) throw new Error(`Namba hii tayari imesajiliwa kwa ${duplicate.name}.`);
  const now = new Date().toISOString();
  const saved = { ...checked, id: checked.id || createId(), createdAt: checked.createdAt || now, updatedAt: now, notesTimeline: checked.notesTimeline || [] };
  await put("customers", saved);
  return saved;
}

// Hubadilisha hatua ya mteja kwa haraka.
export async function changeCustomerStatus(id, status) {
  if (!CUSTOMER_STATUSES.includes(status)) throw new Error("Hatua ya mteja si sahihi.");
  const customer = (await getAll("customers")).find(item => item.id === id);
  if (!customer) throw new Error("Mteja huyu hapatikani.");
  customer.status = status;
  customer.updatedAt = new Date().toISOString();
  await put("customers", customer);
}

// Huhifadhi dokezo jipya kwenye ratiba ya mawasiliano ya mteja.
export async function addCustomerNote(id, text) {
  const customer = (await getAll("customers")).find(item => item.id === id);
  if (!customer) throw new Error("Mteja huyu hapatikani.");
  if (!text.trim()) throw new Error("Andika dokezo kwanza.");
  customer.notesTimeline = customer.notesTimeline || [];
  customer.notesTimeline.unshift({ text: text.trim(), date: new Date().toISOString() });
  await put("customers", customer);
}

// Huondoa mteja baada ya uthibitisho wa mtumiaji.
export const deleteCustomer = id => remove("customers", id);
