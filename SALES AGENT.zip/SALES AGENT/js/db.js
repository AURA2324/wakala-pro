const DB_NAME = "wakala-pro-db";
const DB_VERSION = 1;
const STORE_NAMES = ["customers", "sales", "expenses", "settings"];

// Hutoa kitambulisho cha rekodi hata kwenye kivinjari kisicho secure context.
export function createId() {
  if (globalThis.crypto?.randomUUID) return globalThis.crypto.randomUUID();
  return `${Date.now().toString(36)}-${Math.random().toString(36).slice(2)}-${Math.random().toString(36).slice(2)}`;
}

// Hufungua hifadhidata ya IndexedDB na kuunda makasha yanayohitajika.
export function openDB() {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onupgradeneeded = () => {
      const db = request.result;
      for (const name of STORE_NAMES) {
        if (!db.objectStoreNames.contains(name)) {
          db.createObjectStore(name, { keyPath: name === "settings" ? "key" : "id" });
        }
      }
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(new Error("Imeshindikana kufungua hifadhi ya kifaa."));
  });
}

// Hufanya operesheni moja ya kusoma au kuandika kwenye hifadhidata.
export async function storeRequest(storeName, mode, action) {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(storeName, mode);
    const request = action(transaction.objectStore(storeName));
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error || new Error("Imeshindikana kuhifadhi taarifa."));
    transaction.oncomplete = () => db.close();
    transaction.onerror = () => { db.close(); reject(transaction.error); };
  });
}

// Hurejesha orodha yote kutoka kwenye kasha husika.
export const getAll = store => storeRequest(store, "readonly", objectStore => objectStore.getAll());
// Huhifadhi au kusasisha rekodi moja.
export const put = (store, value) => storeRequest(store, "readwrite", objectStore => objectStore.put(value));
// Hufuta rekodi moja kwa kitambulisho chake.
export const remove = (store, id) => storeRequest(store, "readwrite", objectStore => objectStore.delete(id));
// Husafisha kasha moja la taarifa.
export const clearStore = store => storeRequest(store, "readwrite", objectStore => objectStore.clear());

// Hutoa mipangilio ya kawaida ya mfumo kwa mara ya kwanza.
export async function getSettings() {
  const saved = await getAll("settings");
  const values = Object.fromEntries(saved.map(item => [item.key, item.value]));
  return {
    commission: { halotel: { mode: "percent", value: 10 }, tigo: { mode: "fixed", value: 50000 }, ...(values.commission || {}) },
    monthlyTarget: Number(values.monthlyTarget ?? 500000),
    templates: {
      halotel: "Habari {jina}, karibu! Naweza kukusaidia kupata huduma za Halotel. Nikupigie nikueleze zaidi?",
      tigo: "Habari {jina}, karibu! Tigo Fibre inakupa intaneti ya nyumbani yenye kasi. Ungependa nikutumie maelezo?",
      ...(values.templates || {})
    },
    pinHash: values.pinHash || "",
    notificationsAsked: Boolean(values.notificationsAsked)
  };
}

// Huhifadhi mipangilio kwa kila ufunguo ili iwe rahisi kuibadilisha.
export async function saveSettings(settings) {
  const entries = Object.entries(settings).map(([key, value]) => put("settings", { key, value }));
  await Promise.all(entries);
}

// Huleta nakala ya data kwa kuhifadhi au kurejesha kutoka faili ya JSON.
export async function importDatabase(data) {
  if (!data || !Array.isArray(data.customers) || !Array.isArray(data.sales) || !Array.isArray(data.expenses) || !data.settings || typeof data.settings !== "object") {
    throw new Error("Faili ya nakala haina muundo sahihi.");
  }
  for (const name of ["customers", "sales", "expenses"]) {
    if (!data[name].every(item => item && typeof item === "object" && typeof item.id === "string" && item.id)) {
      throw new Error("Faili la nakala lina rekodi isiyo sahihi.");
    }
  }
  if (Array.isArray(data.settings)) throw new Error("Mipangilio kwenye faili la nakala si sahihi.");
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(STORE_NAMES, "readwrite");
    for (const name of ["customers", "sales", "expenses"]) {
      const store = transaction.objectStore(name);
      store.clear();
      for (const item of data[name]) store.put(item);
    }
    const settingsStore = transaction.objectStore("settings");
    settingsStore.clear();
    for (const [key, value] of Object.entries(data.settings)) settingsStore.put({ key, value });
    transaction.oncomplete = () => { db.close(); resolve(); };
    transaction.onerror = () => { db.close(); reject(transaction.error || new Error("Imeshindikana kurejesha nakala.")); };
    transaction.onabort = () => { db.close(); reject(transaction.error || new Error("Kurejesha nakala kumesitishwa.")); };
  });
}
