import { getAll, getSettings, saveSettings, importDatabase, clearStore } from "./db.js";

// Huunda faili kamili ya nakala ya hifadhidata.
export async function exportBackup() {
  const [customers, sales, expenses, settings] = await Promise.all([getAll("customers"), getAll("sales"), getAll("expenses"), getSettings()]);
  return { app: "Wakala Pro", version: 1, exportedAt: new Date().toISOString(), customers, sales, expenses, settings };
}

// Hupakua CSV kwa muundo wa UTF-8 unaotambua Kiswahili.
export function downloadCSV(filename, rows) {
  const escape = value => `"${String(value ?? "").replaceAll('"', '""')}"`;
  const csv = "\uFEFF" + rows.map(row => row.map(escape).join(",")).join("\r\n");
  const url = URL.createObjectURL(new Blob([csv], { type: "text/csv;charset=utf-8" }));
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  link.click();
  URL.revokeObjectURL(url);
}

// Husoma faili la CSV lenye vichwa vya habari kwa uingizaji wa wateja.
export function parseCSV(text) {
  const rows = [];
  let row = [], cell = "", quoted = false;
  for (let i = 0; i < text.length; i++) {
    const char = text[i];
    if (char === '"' && quoted && text[i + 1] === '"') { cell += '"'; i++; }
    else if (char === '"') quoted = !quoted;
    else if (char === "," && !quoted) { row.push(cell); cell = ""; }
    else if ((char === "\n" || char === "\r") && !quoted) {
      if (char === "\r" && text[i + 1] === "\n") i++;
      row.push(cell); if (row.some(value => value.trim())) rows.push(row);
      row = []; cell = "";
    } else cell += char;
  }
  if (cell || row.length) { row.push(cell); rows.push(row); }
  if (rows.length < 2) throw new Error("Faili la CSV halina data za kuingiza.");
  const headers = rows.shift().map(header => header.replace(/^\uFEFF/, "").trim().toLowerCase());
  return rows.map(values => Object.fromEntries(headers.map((header, index) => [header, values[index] || ""])));
}

// Huondoa data zote pekee baada ya UI kuthibitisha mara mbili.
export async function clearAllData() {
  for (const store of ["customers", "sales", "expenses", "settings"]) await clearStore(store);
}

export { getSettings, saveSettings, importDatabase };

// Huhifadhi PIN kama hash ya SHA-256, bila kuweka namba ghafi.
export async function hashPin(pin) {
  if (!/^\d{4}$/.test(pin)) throw new Error("PIN lazima iwe na tarakimu nne.");
  if (!globalThis.crypto?.subtle) throw new Error("PIN inahitaji programu ifunguliwe kupitia HTTPS au localhost.");
  const bytes = new TextEncoder().encode(pin);
  const digest = await crypto.subtle.digest("SHA-256", bytes);
  return [...new Uint8Array(digest)].map(byte => byte.toString(16).padStart(2, "0")).join("");
}
